package com.cg.banking.daoservices;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.banking.beans.Account;
@Qualifier("JpaRepository")
public interface BankingDAOAccount extends JpaRepository<Account, Long>{
}
