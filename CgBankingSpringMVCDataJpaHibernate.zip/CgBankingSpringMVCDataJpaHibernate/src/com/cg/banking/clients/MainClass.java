package com.cg.banking.clients;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingService;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingService bankingService=(BankingService) context.getBean("bankingService");
		
		//bankingService.depositAmount(2024225153,1000);
		//bankingService.withdrawAmount(2024225153,1000);
		//bankingService.fundTransfer(2024225152, 2024225153, 2000);
		//Account account=bankingService.getAccountDetails(2024225153);
		//System.out.println(account.toString());
		/*List<Account> list=new ArrayList<Account>();
		list =bankingService.getAllAccountDetails();
		for(Account str:list)
			System.out.println(str.toString());*/
		/*List<Transaction> list=new ArrayList<Transaction>();
		list=bankingService.getAccountAllTransaction(2024225152);
		for(Transaction str:list)
			System.out.println(str.toString());*/
		
		/*List<Transaction> list=new ArrayList<Transaction>();
		list=bankingService.getAllTransactionDetails();
		for(Transaction str:list)
			System.out.println(str.toString());*/
		
		/*Account account=new Account("Saving",5000,new Customer("Ashav Kumar","ashav21011996@gmail.com","Pune","HHTPK0434B"));
		String accString=bankingService.openAccount("Ashav Kumar","ashav21011996@gmail.com","Pune","HHTPK0434B","Saving",5000);
		 Account account=new Account();
		 List<Account> list=new ArrayList<Account>();
		 list.add(account);*/

		 //Customer customer=new Customer(,);
		 //long accountTo,accountFrom;
		 //long customerId=bankingService.openAccount("Ashav","ashav2101@gmail.com","Pune","HHTPK0434B","Saving",1500,"Cricket");
		 //Customer customer= bankingService.getCustomerDetails(customerId);	
		 
		 Customer customer=bankingService.openAccount("NEELAM","ashav2101@gmail.com","Pune","HHTPK0434B","Saving",1200,"Cricket");
		 System.out.println(customer.getCustomerId());
		 Customer customer2= bankingService.getCustomerDetails(customer.getCustomerId());	
		 System.out.println(customer2.toString());
		System.out.println(bankingService.fundTransfer(2752, 2902, 100));
		 List<Transaction> transactions=bankingService.getAccountAllTransaction(52);
		 for(Transaction transaction:transactions)
			 System.out.println(transaction.toString());
			 //bankingService.withdrawAmount(account.getAccountNo(), 200);
		 //System.out.println(bankingService.getCustomerDetails(302));
		//System.out.println(accString);
	}
}
