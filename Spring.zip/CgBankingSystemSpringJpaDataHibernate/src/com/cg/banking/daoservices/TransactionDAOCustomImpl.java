package com.cg.banking.daoservices;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Transaction;
@Component("transactionDAOCustom")
public class TransactionDAOCustomImpl implements TransactionDAOCustom {
	/*@Autowired
	EntityManagerFactory factory;
	@Override
	public ArrayList<Transaction> findAccountAllTransactions(long accountNo){
		EntityManager entityManager = factory.createEntityManager();
		Query query = entityManager.createQuery("from Transaction a");
		@SuppressWarnings("unchecked")
		ArrayList<Transaction> list=(ArrayList<Transaction>)query.getResultList();
		return list;
	}*/
}
