package com.cg.banking.daoservices;
import java.util.ArrayList;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cg.banking.beans.Transaction;
@Transactional
public interface TransactionDAO extends JpaRepository<Transaction,Integer>{
	@Query("t from Transaction t where accountNo=:accountNo")
	ArrayList<Transaction> findAccountAllTransactions(@Param("empId") long accountNo);
}
