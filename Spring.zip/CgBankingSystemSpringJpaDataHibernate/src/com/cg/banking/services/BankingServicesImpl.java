package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.exceptions.TransactionRollbackException;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOCustom;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	AccountDAO accountDao;
	@Autowired
	TransactionDAO transactionDAO;
	@Autowired
	TransactionDAOCustom transactionDAOCustom;
	@Override
	public Account openAccount(int pinNumber,String accountType, float accountBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
		if(accountType == "Saving" || accountType == "Current"){
			Account account = new Account(pinNumber,accountType, accountBalance);
			accountDao.save(account);
			/*Transaction transaction = new Transaction();
		accountDao.save(transaction);
			 */
			System.out.println(account.getAccountNo());
			return account;
		}
		else
			throw new InvalidAccountTypeException("Enter the correct account type, either saving or current");
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException {
		Account account  = accountDao.findById(accountNo).get();
		Transaction transaction=new Transaction();
		transaction.setTransactionType("Net Banking");
		if(account == null)throw new AccountNotFoundException("Account details not found");
		if(amount<0)
			throw new InsufficientAmountException("amount is insufficient");	
		account.setAccountBalance(account.getAccountBalance()+amount);
		transactionDAO.save(transaction);
		//account.setTransactions(accountDao.save(new Transaction(accountNo,amount,"NetBanking")));
		accountDao.save(account);
		System.out.println("amount is deposited");
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		Account account  = accountDao.findById(accountNo).get();

		if(account == null)throw new AccountNotFoundException("Account details not found");
		if(account.getAccountBalance()< amount)throw new InsufficientAmountException("account balance is insufficient");
		if(account.getPinNumber()!= pinNumber)throw new InvalidPinNumberException("Enter correct PIN");
		account.setAccountBalance(account.getAccountBalance()-amount);
		Transaction transaction = new Transaction();
		transaction.setTransactionType("Net Banking");
		transactionDAO.save(transaction);
		accountDao.save(account);
		System.out.println("amount is withdrawn");
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account accountTo = accountDao.findById(accountNoTo).get();
		Account accountFrom = accountDao.findById(accountNoFrom).get();
		if(accountFrom.getAccountNo() != accountNoFrom)throw new AccountNotFoundException("Account details not found");
		if(accountTo.getAccountNo() != accountNoTo)throw new AccountNotFoundException("Account details not found");
		if(accountFrom.getPinNumber()!= pinNumber)throw new InvalidPinNumberException("Enter correct PIN");
		if(accountFrom.getAccountBalance()< transferAmount)throw new InsufficientAmountException("account balance is insufficient");
		if(accountTo.getAccountBalance()<0)throw new AccountBlockedException("account is blocked");
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
		accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		Transaction transaction1 = new Transaction();
		Transaction transaction2 = new Transaction();
		transaction1.setTransactionType("Net Banking");
		transaction2.setTransactionType("Net Banking");
		transactionDAO.save(transaction1);
		transactionDAO.save(transaction2);
		accountDao.save(accountFrom);
		accountDao.save(accountTo);

		System.out.println("amount is withdrawn");
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException{
		Account account = accountDao.findById(accountNo).get();
		if(account == null)throw new AccountNotFoundException("Account details are not found");
		System.out.println("account details are: ");
		return account;
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException{
		ArrayList<Account> accounts = (ArrayList<Account>) accountDao.findAll();
		System.out.println("all accounts details are : ");
		return accounts;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		ArrayList<Transaction> transactions = transactionDAO.findAccountAllTransactions(accountNo);
		if(transactions == null);
		System.out.println(("the function getAccountAllTransaction is executed"));
		return transactions;
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		return null;
	}
}
