package com.cg.banking.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.TransactionRollbackException;
import com.cg.banking.services.BankingServices;
public class MainClass {
	public static void main(String[] args) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidAmountException, InvalidAccountTypeException, InvalidPinNumberException, AccountBlockedException, TransactionRollbackException {
		/*Address address = new Address("Pune","Maharashtra","India",411057);
		address.getCity();
		Address address2 = new Address(address.getCity(),address.getState(), null, 0);
		System.out.println(address2.getCity());
		System.out.println(address.getCity());
		*/
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices = (BankingServices) context.getBean("bankingServices") ;
		System.out.println(bankingServices.openAccount(1234, "Saving", 10000));
		/*AccountDAO dao = new AccountDAOImpl();
		Account account1 = new Account();
		Transaction transaction = new Transaction();
		account1 = bankingServices.openAccount(5600,"Saving", 10000);
		System.out.println(account1);
		System.out.println(bankingServices.depositAmount(1, 5000));
		System.out.println(bankingServices.withdrawAmount(account1.getAccountNo(), 5000, account1.getPinNumber()));
		Account account2 = new Account();
		account2 = bankingServices.openAccount(5633,"Saving",5000);
		System.out.println(account2);
		bankingServices.fundTransfer(account1.getAccountNo(), account2.getAccountNo(), 1000,account2.getPinNumber());*/
		System.out.println(bankingServices.getAllAccountDetails());
		System.out.println(bankingServices.depositAmount(1, 5000));
		System.out.println(bankingServices.getAccountDetails(1));
		System.out.println(bankingServices.getAccountAllTransaction(1));
	}

}
