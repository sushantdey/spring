package com.cg.project.services;

public interface GreetingServices {
	public void sayHello(String name);
}
